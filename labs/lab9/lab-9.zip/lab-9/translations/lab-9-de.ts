<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>CoverPage</name>
    <message>
        <source>My Cover</source>
        <translation>Mein Cover</translation>
    </message>
</context>
<context>
    <name>SecondPage</name>
    <message>
        <source>Nested Page</source>
        <translation>Unterseite</translation>
    </message>
    <message>
        <source>Item</source>
        <translation>Element</translation>
    </message>
</context>
</TS>
